package com.Booking;

import javax.management.Query;

public class Reservation {
	
	
	
	public static int getkilometers(String jDate, String fromDate, String toDate) {
		// TODO Auto-generated method stub
		
		String query=null;
		Query objQuery=null;
		try
		{
			
		query="Select kilometers,busid from ROUTEMASTER where journeydate=?1 and fromdate=?2 and todate?=3";
	
		objQuery=con.CreateQuery(query);
		objQuery.se
		
		}
		
		
		catch()
		{
			
		}
		
		return 0;
	}
}
