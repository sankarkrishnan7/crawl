package com.Booking;

import java.util.Scanner;

public class ReservationMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanobj = new Scanner(System.in);  
	    System.out.println("Enter Journey,From&To Date : ");

	    String jDate = scanobj.nextLine();  // Read user input
	   System.out.println("Username is: " + jDate);
	    
	    String fromDate = scanobj.nextLine();  // Read user input
	    System.out.println("FromDate is: " + fromDate);
	    
	    
	    String toDate = scanobj.nextLine();  // Read user input
	    System.out.println("Todate is: " + toDate);
	    
	    int kilometers=Reservation.getkilometers(jDate,fromDate,toDate);
	  }

	
	}

