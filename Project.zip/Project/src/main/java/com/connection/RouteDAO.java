package com.connection;

public class RouteDAO {
	
	Class.forName("oracle.jbdc.driver.OracleDriver");
	Connection con= DriverManager.registerDriver(new oracle.jdbc.OracleDriver()); 
	  
     //Reference to connection interface 
     con = DriverManager.getConnection(url,user,pass);

}
